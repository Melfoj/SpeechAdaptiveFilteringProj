function histogrami(x,fs,T,N)

figure;
xusr=usrednjifunkc(x,fs,T);

subplot(1,2,1);

[elem,r]=histogram(mag2db(xusr),N);
plot(r,elem/sum(elem)),xlabel('Nivo [dB]'),ylabel('Verovatnoca');

subplot(1,2,2);

kumf=cumsum(elem/sum(elem));

L5=0.05*ones(1,length(r));
L95=0.95*ones(1,length(r));
plot(r,kumf,r,L5,'--',r,L95,'--'),xlabel('Nivo [dB]'),ylabel('Verovatnoca');
end;
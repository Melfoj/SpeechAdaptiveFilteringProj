clc;
close all;
clear all;

[x1,fs1]=audioread('govor.wav');
vremenska_analiza(x1,fs1);

%[x2,fs2]=audioread('orkestar.wav');
%vremenska_analiza(x2,fs2);

%trajanje=10;
%fssuma=96000;
%mu=0;
%std=1;
%beli_sum=mu+std.*randn(1,trajanje*fssuma);
%audiowrite('beli_sum.wav',beli_sum,fs1,'BitsPerSample',24);

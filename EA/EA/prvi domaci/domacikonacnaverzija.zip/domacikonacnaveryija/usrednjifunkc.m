
function xusr=usrednjifunkc(x,fs,T)

duz=T*fs;
t=length(x)/fs;
Nuk=fix(t/T);

for i=1:Nuk
niz((i-1)*duz+1:i*duz)=mean(x((i-1)*duz+1:i*duz).^2);
end
xusr=niz;
end
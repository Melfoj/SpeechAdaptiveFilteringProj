function vremenska_analiza(xx,fs)


pmax=max(abs(xx));
x=xx/pmax;
t=(0:length(x)-1)/fs;
figure, plot(t,x), legend('signal x(t)');

%rms
peff=rms(x);

peffdb=mag2db(peff);

%krest faktor
c=pmax/peff;
cdb=mag2db(c);


%usrednjavanje
T=[0.01 0.2 1];
usrednjavanje(x,fs,T);

%histogrami
%N=100;
%histogrami(x,fs,T(1),N);
%histogrami(x,fs,T(2),N);
%histogrami(x,fs,T(3),N);


end